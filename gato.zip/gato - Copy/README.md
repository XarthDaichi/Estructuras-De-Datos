# Operacion Gatito
Proyecto 2 - Estructuras de Datos

## Integrantes
Diego Quiroz Artiñano \
Luis Antonio Montes de Oca Ruiz \
Mauricio Vargas Vicarioli
