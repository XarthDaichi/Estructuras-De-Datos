#include "palabras.h"

Palabras::Palabras() : ptrPalabras{ new std::string*[DEFAULT]} {}

Palabras::Palabras(size_t tam) {
	// TODO
	// Implementar constructor con un tama�o definido
}

Palabras::Palabras(const Palabras&) {
	// TODO
	// Implementar constructor de copia
}

Palabras::~Palabras() {
	// TODO
	// Implementar destructor
}

// Retorna un n�mero entero igual o mayor a cero si carg� correctamente
// El n�mero puede representar la cantidad de palabras cargadas
// Retorna -1 si hubo un error 
int Palabras::CargarDeArchivo(std::string nombre) {
	// TODO
	// Cargar palabras desde un archivo
}

// Retorna un n�mero entero igual o mayor a cero si guard� correctamente
// El n�mero puede representar la cantidad de palabras guardadas
// Retorna -1 si hubo un error 
int Palabras::GuardarEnArchivo() {
	// TODO
	// Guardar las palabras en el archivo
}

// Almacena una nueva palabra en el vector
void Palabras::AgregarPalabra(std::string) {
	// TODO
	// Implementar la inserci�n de palabras en la clase
}