#include <iostream>
#include "palabras.h"

int main() {
	
	
	Palabras* p1 = new Palabras();
	Palabras* p2 = new Palabras(3);

	p2->AgregarPalabra("Hola");
	p2->AgregarPalabra("Mundo");
	p2->AgregarPalabra("Hello");

	for (size_t i = 0; i < 10; i++) {
		std::cout << "p1: \t";
		if (p1->getPtrPalabras()[i] != NULL) {
			std::cout << *p1->getPtrPalabras()[i] << "\t";
		}
		else {
			break;
		}
	}
	std::cout << "\n";
	for (size_t i = 0; i < 3; i++) {
		std::cout << "p2: \t";
		if (p2->getPtrPalabras()[i] != NULL) {
			std::cout << *p2->getPtrPalabras()[i] << "\t";
		}
		else {
			break;
		}
	}
	std::cout << "\n";

	p2->GuardarEnArchivo("p2.txt");

	p1->CargarDeArchivo("p2.txt");
	p1->AgregarPalabra("World");

	for (size_t i = 0; i < 10; i++) {
		std::cout << "p1: \t";
		if (p1->getPtrPalabras()[i] != NULL) {
			std::cout << *p1->getPtrPalabras()[i] << "\t";
		}
		else {
			break;
		}
	}
	std::cout << "\n";
	for (size_t i = 0; i < 3; i++) {
		std::cout << "p2: \t";
		if (p2->getPtrPalabras()[i] != NULL) {
			std::cout << *p2->getPtrPalabras()[i] << "\t";
		}
		else {
			break;
		}
	}
	std::cout << "\n";

	Palabras* p3 = new Palabras(*p2);
	for (size_t i = 0; i < 3; i++) {
		std::cout << "p3: \t";
		if (p3->getPtrPalabras()[i] != NULL) {
			std::cout << *p3->getPtrPalabras()[i] << "\t";
		}
		else {
			break;
		}
	}
	std::cout << "\n";

	p1->~Palabras();
	p2->~Palabras();
	p3->~Palabras();

	return 0;
}